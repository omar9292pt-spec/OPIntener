# OP Intener — proyecto inicial

Prototipo inicial de interfaz Android. No incluye todavía una conexión VPN funcional ni un backend de licencias.

## Compilar desde GitHub Actions
1. Sube el contenido de esta carpeta a un repositorio GitHub propio (incluida `.github/workflows/android.yml`).
2. Abre la pestaña **Actions** y ejecuta **Build OP Intener APK** con **Run workflow** si no se inició automáticamente.
3. Cuando termine correctamente, abre la ejecución y descarga el artefacto **OP-Intener-debug-apk**.
4. Descomprime el artefacto ZIP y abre el APK en Android para instalarlo.

El APK de depuración es para pruebas. La aplicación es solo una interfaz de demostración; no es todavía una VPN funcional.
