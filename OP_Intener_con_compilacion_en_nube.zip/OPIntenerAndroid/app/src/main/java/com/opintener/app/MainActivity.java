package com.opintener.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private final int BLACK = 0xFF080808;
    private final int PANEL = 0xFF171717;
    private final int GOLD = 0xFFD6AD45;
    private final int WHITE = 0xFFF7F4EA;
    private EditText licenseInput;
    private TextView status;
    private boolean locallyActivated = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        showHome();
    }

    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable shape(int color, int radius, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius));
        if (strokeColor != 0) d.setStroke(dp(1), strokeColor);
        return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }

    private TextView button(String value) {
        TextView b = text(value, 16, BLACK, true); b.setGravity(Gravity.CENTER); b.setPadding(dp(16), dp(14), dp(16), dp(14));
        b.setBackground(shape(GOLD, 14, 0)); return b;
    }

    private void showHome() {
        ScrollView scroll = new ScrollView(this); scroll.setBackgroundColor(BLACK);
        LinearLayout page = column(); page.setPadding(dp(22), dp(30), dp(22), dp(28)); scroll.addView(page);

        TextView brand = text("OP INTENER", 30, GOLD, true); brand.setGravity(Gravity.CENTER); page.addView(brand);
        TextView tagline = text("CONEXIÓN • SEGURIDAD • CONTROL", 11, WHITE, true); tagline.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(-1, -2); tlp.topMargin = dp(6); page.addView(tagline, tlp);

        LinearLayout card = column(); card.setPadding(dp(18), dp(20), dp(18), dp(20)); card.setBackground(shape(PANEL, 20, 0xFF4A3B1D));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2); cp.topMargin = dp(28); page.addView(card, cp);
        TextView state = text(locallyActivated ? "LICENCIA ACTIVADA EN ESTE DISPOSITIVO" : "ACTIVA TU LICENCIA", 14, GOLD, true); state.setGravity(Gravity.CENTER); card.addView(state);
        licenseInput = new EditText(this); licenseInput.setSingleLine(true); licenseInput.setHint("Introduce tu código"); licenseInput.setHintTextColor(0xFF999999); licenseInput.setTextColor(WHITE); licenseInput.setPadding(dp(12), dp(12), dp(12), dp(12)); licenseInput.setBackground(shape(0xFF242424, 10, 0xFF5A4A29));
        LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(-1, -2); ilp.topMargin = dp(16); card.addView(licenseInput, ilp);
        TextView activate = button("ACTIVAR CÓDIGO"); LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(-1, -2); alp.topMargin = dp(12); card.addView(activate, alp);
        activate.setOnClickListener(v -> {
            String code = licenseInput.getText().toString().trim();
            if (code.isEmpty()) { toast("Introduce un código de licencia."); return; }
            toast("La validación real requiere conectar el servidor de licencias.");
        });

        TextView connTitle = text("CONEXIÓN VPN", 18, WHITE, true); LinearLayout.LayoutParams ctp = new LinearLayout.LayoutParams(-1, -2); ctp.topMargin = dp(28); page.addView(connTitle, ctp);
        TextView carrier = text("Operadora", 13, 0xFFBBBBBB, false); LinearLayout.LayoutParams c1 = new LinearLayout.LayoutParams(-1, -2); c1.topMargin = dp(12); page.addView(carrier, c1);
        Spinner carriers = new Spinner(this); String[] choices = {"Seleccionar operadora", "OXXO CEL", "Telcel", "AT&T", "Movistar", "Otra"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, choices); carriers.setAdapter(adapter); page.addView(carriers);
        TextView serverLabel = text("Servidor", 13, 0xFFBBBBBB, false); LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1, -2); slp.topMargin = dp(12); page.addView(serverLabel, slp);
        Spinner servers = new Spinner(this); ArrayAdapter<String> sa = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, new String[]{"Seleccionar servidor", "Servidor propio (pendiente de configurar)"}); servers.setAdapter(sa); page.addView(servers);

        TextView connect = button("CONECTAR"); LinearLayout.LayoutParams conp = new LinearLayout.LayoutParams(-1, -2); conp.topMargin = dp(18); page.addView(connect, conp);
        status = text("Estado: sin conexión", 13, 0xFFBDBDBD, false); status.setGravity(Gravity.CENTER); LinearLayout.LayoutParams stp = new LinearLayout.LayoutParams(-1, -2); stp.topMargin = dp(12); page.addView(status, stp);
        connect.setOnClickListener(v -> {
            status.setText("Estado: falta configurar un servidor VPN autorizado.");
            toast("La interfaz está lista; falta el servidor y el protocolo VPN.");
        });

        TextView note = text("Gracias por comprar con OP contactame para mas aplicaciones como esta 2491785859", 13, GOLD, false);
        note.setGravity(Gravity.CENTER); note.setPadding(dp(8), dp(24), dp(8), dp(10)); page.addView(note);
        TextView disclaimer = text("Versión inicial de diseño. La conexión VPN y la validación de licencias aún no están implementadas. Una VPN necesita una conexión de red subyacente y un servidor accesible.", 11, 0xFF999999, false);
        disclaimer.setGravity(Gravity.CENTER); disclaimer.setPadding(dp(4), dp(8), dp(4), dp(8)); page.addView(disclaimer);
        setContentView(scroll);
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
}
